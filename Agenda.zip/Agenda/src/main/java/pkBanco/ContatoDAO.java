/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkBanco;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import pkNegocio.Contato;

/**
 *
 * @author Aluno
 */
public class ContatoDAO {
    private String usuarioBanco = "postgres";
    private String senhaBanco = "1234";
    private String urlBanco = "jdbc:postgresql://localhost";
    
    private Connection getConnection(){
        Connection connection = null;
        try{
            Class.forName("org.postgresql.Driver");
            connection = DriverManager.getConnection(urlBanco,usuarioBanco,
                    senhaBanco);
        }catch(SQLException ex){
            ex.printStackTrace();
        }catch(ClassNotFoundException ex){
            ex.printStackTrace();
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return connection;
    }
    
    public int cadastrarContato (Contato contato){
        int cadastrado = 0;
        try{
            Connection conexao = getConnection();
            if (conexao != null){
                PreparedStatement cadastrar = conexao.prepareStatement
                        ("INSERT INTO contatos(nome,telefone) VALUES (?,?)");
                cadastrar.setString(1,contato.getNome());
                cadastrar.setString(2,contato.getTelefone());
                cadastrar.executeUpdate();
                cadastrado = 1;
                cadastrar.close();
                conexao.close();
            }
        
        }catch(SQLException ex){
            ex.printStackTrace();
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return cadastrado;
    }
}
